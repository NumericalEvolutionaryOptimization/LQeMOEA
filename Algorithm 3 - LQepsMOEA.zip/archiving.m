function [Ax, Ay, Nx, Ny, Dx, Dy, Rx, Ry] = archiving(Ax, Ay, Ox, Oy, eps, dx, iteration)
    Oy2 = Oy;
    Ay2 = Ay;
    if ~isempty(Ax)
        Ay2 = (Ay-min([Ay]))./(max([Ay])-min([Ay]));
        Oy2 = (Oy-min([Ay]))./(max([Ay])-min([Ay]));
    end    
    
    Ay2 = ishibuchi(Ay2, 2, 1e-2);
    Oy2 = ishibuchi(Oy2, 2, 1e-2);
    
    state = rng;
    rng(42);
    [Ax2,Ay2,Nx,Ny,Dx,Dy,Rx,Ry,I_N,I_D,I_R] = CleanAndArchive(Ax, Ay2, Ox, Oy2, eps, dx, 100, 50, iteration);
    rng(state);

    Bx = [Ax; Ox];
    By = [Ay; Oy];

    Nx = Bx(I_N,:);
    Ny = By(I_N,:);
    Dx = Bx(I_D,:);
    Dy = By(I_D,:);
    Rx = Bx(I_R,:);
    Ry = By(I_R,:);

%     Pop = SOLUTION(Nx, Ny, zeros(size(Nx,1),1));    
%     Pop = EnvironmentalSelectionLQ(Pop, size(Ax2,1) - size(Dx,1));
%     Nx = Pop.decs;
%     Ny = Pop.objs;

    Ax = [Nx; Dx];
    Ay = [Ny; Dy];
end

