
% VERSION 2.0 
% 14/MAR/2024

function [Ax,Ay,Nx,Ny,Dx,Dy,Rx,Ry,I_N,I_D,I_R] = CleanAndArchive(Ax, Ay, Px, Py,eps,delta_neigh,gensize,ND_size,iteration)

if mod(iteration,5) == 0 && size(Ax,1)>=gensize
    Bx = [Ax; Px];
    By = [Ay; Py];
    %-------------------------inicio de cleanup---------------------------%
    relax = false;
    domnodom = true;
    [~,~,~,~,I_c] = cleanup(Bx,By,domnodom,relax,gensize);
    
    %Relax cleanup if strict:
    if (size(find(I_c==1),1) < gensize) && (size(Ax,1) >= gensize)
        relax = true;
        [~,~,~,~,I_c] = cleanup(Bx,By,domnodom,relax,gensize);
    end
    %cleaned points:
    Px_c = Bx(I_c==1,:);
    Py_c = By(I_c==1,:);
    %-----------------------------Fin Cleanup-----------------------------%


    [Ax,Ay,Nx,Ny,Dx,Dy,Rx,Ry,I_N,I_D,I_R] = ArchiveUpdateLQepsDNDClustX([], [], Px_c, Py_c,eps,delta_neigh,gensize,ND_size);
%     [Ax,Ay,Nx,Ny,Dx,Dy,Rx,Ry] = ArchiveUpdateLQepsR([], [], Px_c, Py_c,eps,delta_neigh,gensize);

    Rx = [Rx;Bx(I_c==-1,:)];
    Ry = [Ry;By(I_c==-1,:)];
    I_R = [I_R';find(I_c==-1)];
    newI = find(I_c==1);
    I_N = newI(I_N);
    I_D = newI(I_D);
else
    [Ax,Ay,Nx,Ny,Dx,Dy,Rx,Ry,I_N,I_D,I_R] = ArchiveUpdateLQepsDNDClustX(Ax, Ay, Px, Py,eps,delta_neigh,gensize,ND_size);
%     [Ax,Ay,Nx,Ny,Dx,Dy,Rx,Ry] = ArchiveUpdateLQepsR(Ax, Ay, Px, Py,eps,delta_neigh,gensize);
end

end

%-------------Clean Up FUNCTION--------------%
function [Ax_c,Ay_c,eps_fin,minpts_fin,I_c] = cleanup(Ax,Ay,domnondom,relax,gensize)
    
    ifplot = false;
    x_clust = false;
    num_obj = size(Ay,2);
%     x_clust = true;
%     num_obj = size(Ax,2);

    if domnondom
        [Nx, Ny, Dx, Dy, I] = nondom(Ax,Ay);
        numN = size(Nx,1);
        I_N = find(I==1);
        I_D = find(I==0);
    else
        Dx = Ax;
        Dy = Ay;
    end

%     tic
    %-------------------------inicio de cleanup---------------------------%
    if isempty(Dx)
        Ax_c = Ax;
        Ay_c = Ay;
    else
        num_points = size(Dx,1);
        Distance = zeros(num_points);

        for i=1:num_points
            for j=i:num_points
                if x_clust
                    Distance(i,j) = norm( Dx(i,:)-Dx(j,:) );
                else
                    Distance(i,j) = norm( Dy(i,:)-Dy(j,:) );
                end
                Distance(j,i) = Distance(i,j);
            end
        end

        avrg_dist = sum(sum(Distance)/size(Distance,1))/size(Distance,1);
        if relax
            if num_obj == 2
                eps = 2*(0.01:0.01:0.025)*avrg_dist;
                % eps = (0.05:0.05:0.1)*avrg_dist;
            else
                eps = 2*num_obj*(0.01:0.01:0.025)*avrg_dist;
%                 eps = 2*(0.01:0.01:0.025)*avrg_dist;
            end
            minpts = 3:4;
        else
            if num_obj == 2
        %         eps = (0.10:0.01:0.17)*avrg_dist; %from 1/10 to 1/5 of min norm
        %         eps = (0.05:0.01:0.1)*avrg_dist; 
                eps = (0.01:0.01:0.025)*avrg_dist; 
        %         eps = (0.0015:0.01:0.0015)*avrg_dist;
            else
        %         eps = (0.10:0.01:0.17)*avrg_dist; %from 1/10 to 1/5 of min norm
        %         eps = (0.05:0.01:0.1)*avrg_dist; 
                eps = num_obj*(0.01:0.01:0.025)*avrg_dist; 
        %         eps = (0.0015:0.01:0.0015)*avrg_dist;
            end
            minpts = 3:4;
    %         minpts = 4;
    %         minpts = 2:3;
    %         minpts = 2:2;
        end
        num_eps = length(eps);
        num_minpts = length(minpts);
        % TO HERE ------------------------------

        WLC_min = inf;
        % WLC_max = 0;
        C_fin = {};
        Cy_fin = {};
        eps_fin = 0;
        minpts_fin = 0;
        num_clust_fin = 0;
        idx_fin = 0;
        for i=1:num_eps
%             disp(['Current Epsilon:' int2str(i) '/' int2str(num_eps) ])
            for j=1:num_minpts
%                 disp(['Current minpts:' int2str(j) '/' int2str(num_minpts) ])
                if x_clust
                    [idx,~] = dbscan(Dx,eps(i),minpts(j));
                else
                    [idx,~] = dbscan(Dy,eps(i),minpts(j));
                end
                num_clusters = max(idx);
                C = {};
                Cy = {};
                for k=1:num_clusters
                    C{k} = Dx(find(idx==k),:);
                    Cy{k} = Dy(find(idx==k),:);
                end
                WLC = WeakestLinkCluster(C);
                if WLC < WLC_min
        %         if WLC > WLC_max
                    WLC_min = WLC;
        %             WLC_max = WLC;
%                     disp(['NUEVO WLC= ' num2str(WLC) ', eps=' int2str(i) ', minpts=' int2str(minpts(j))])
                    eps_fin = eps(i);
                    C_fin = C;
                    Cy_fin = Cy;
                    minpts_fin = minpts(j);
                    num_clust_fin = num_clusters;
                    idx_fin = idx;
        %             %COMENTAR:
        %             figure
        %             gscatter(Dx(:,1),Dx(:,2),idx);
        %             title(['eps=' int2str(i) '=' num2str(eps(i)) ',minpts=' int2str(minpts(j))])
        %             saveas(gcf,[pwd 'ClusterFilter_eps=' int2str(i) '=' num2str(eps(i)) ',minpts=' int2str(minpts(j)) '.png'])
        %             save([pwd 'ClusterFilter_eps=' int2str(i) '=' num2str(eps(i)) ',minpts=' int2str(minpts(j)) '.mat'])
                end
            end
        end
        %Returning last values
        C = C_fin;
        Cy = Cy_fin;
        eps = eps_fin;
        minpts = minpts_fin;
        num_clust = num_clust_fin;
        idx = idx_fin;
        
        if ifplot ~= false
            %-------COMMENT! DEBUG------%
            Dx_c = [];
            Dy_c = [];
            for k=1:length(C)
                Dx_c = [Dx_c;C{k}];
                Dy_c = [Dy_c;Cy{k}];
            end
            figure(Visible="off")
            scatter(Dy(:,1),Dy(:,2),'x')
            hold on
            scatter(Dy_c(:,1),Dy_c(:,2),'filled')
            saveas(gcf,[pwd '/MMF/B_MMF1_clean_' int2str(ifplot) '_y.png'])
            figure(Visible="off")
            scatter(Dx(:,1),Dx(:,2),'x')
            hold on
            scatter(Dx_c(:,1),Dx_c(:,2),'filled')
            saveas(gcf,[pwd '/MMF/B_MMF1_clean_' int2str(ifplot) '_x.png'])
            %-------END COMMENT! DEGUB------%
        end
        
        if domnondom
            Ax_c = Nx;
            Ay_c = Ny;
        else
            Ax_c = [];
            Ay_c = [];
        end
        for k=1:length(C)
            Ax_c = [Ax_c;C{k}];
            Ay_c = [Ay_c;Cy{k}];
%             figure
%             scatter(C{k}(:,1),C{k}(:,2))
%             hold on
        end
    end

    if domnondom
        I_c = ones(size(Ax,1),1);
        I_c(I_D(idx==-1)) = -1;
    else
        I_c = idx; %TESTEAR!!! PARA CASO domnondom = false !!!
    end
    
    if relax && size(Ax_c,1)<gensize
        disp('CLEANING OUTPUTS LESS THAN gensize POINTS!!!')
        missing = gensize - size(Ax_c,1);
        [N2x, N2y, D2x, D2y, I2] = nondom(Dx,Dy);
        I_N2 = find(I2==1);
        I_D2 = find(I2==0);
        secnd_front_pts = size(N2x,1);
        rest_front_pts = size(D2x,1);
        if secnd_front_pts > missing
            newpts = randsample(secnd_front_pts,missing);
            Ax_c(end+1:gensize,:) = N2x(newpts,:);
            Ay_c(end+1:gensize,:) = N2y(newpts,:);
            I_c(I_D(I_N2(newpts))) = 1; %DEBE ESTAR EN -1, cambio a 1
        else
            Ax_c(end+1:end+secnd_front_pts,:) = N2x;
            Ay_c(end+1:end+secnd_front_pts,:) = N2y;
            I_c(I_D(I_N2)) = 1; %DEBE ESTAR EN -1, cambio a 1
            missing = gensize - size(Ax_c,1);
            newpts = randsample(rest_front_pts,missing);
            Ax_c(end+1:gensize,:) = D2x(newpts,:);
            Ay_c(end+1:gensize,:) = D2y(newpts,:);
            I_c(I_D(I_D2(newpts))) = 1; %DEBE ESTAR EN -1, cambio a 1
        end
        
        if size(Ax_c,1)<gensize
            disp('CLEANING STILL OUTPUTS LESS THAN gensize POINTS!!!! REVISAR!!!')
        end
    end

end
%--------------------------------------------%

%-------------GRID SEARCH FUNCTIONS----------%
function WLC = WeakestLinkCluster(C)

    num_clust = length(C);
%     inter_clust_WLP = zeros(1,num_clust);

    %---This part computes the maximum link intra cluster-----%
    C_sizes = zeros(1,num_clust);
    max_clust = zeros(1,num_clust); %MAXIMUM LINK INTRA CLUSTER
    for i=1:num_clust
        C_sizes(i) = size(C{i},1);
    end
    for i=1:num_clust %compute value over all clusters
        for j=1:C_sizes(i)-1 %find maximum dist in cluster
            dist = norm(C{i}(j,:)-C{i}(j+1,:));
            if dist > max_clust(i)
                max_clust(i) = dist;
            end
        end
    end
    %---------------------------------------------------------%

    %----COMPUTING INTRA CLUSTER WLP-----------%
    intra_cluster_WLP = 0;
    for i=1:num_clust-1
        for j=1:C_sizes(i)-1
            for k=j+1:C_sizes(i)
                temp = WeakestLinkPoints(max_clust,C{i}(j,:),C{i}(k,:),C);
                if temp > intra_cluster_WLP
                    intra_cluster_WLP = temp;
                end
            end
        end
    end
    %------------------------------------------%

    %----SHORTEST BETWEEN CLUSTER DISTANCE------%
    inter_clust_WLP = inf;
    for i=1:num_clust-1
        for j=i+1:num_clust
            temp = min_dist_2_clust(C{i},C{j});
            if temp < inter_clust_WLP
                inter_clust_WLP = temp;
            end
        end
    end
    %------------------------------------------%

    WLC = intra_cluster_WLP/inter_clust_WLP;


end

function WLP = WeakestLinkPoints(max_clust,x,y,C)
    num_clust = size(C,2);
    WLP_vec = zeros(1,num_clust);
    dist_vec = zeros(1,3);
    for i=1:num_clust
        dist_vec(1) = norm(C{i}(1,:)-x);
        dist_vec(2) = norm(C{i}(end,:)-y);
        dist_vec(3) = max_clust(i);
        WLP_vec(i) = max(dist_vec);
    end
    WLP = min(WLP_vec);
end

function min = min_dist_2_clust(X,Y)
    min = inf;
    X_size = size(X,1);
    Y_size = size(Y,1);
    for i=1:X_size
        for j=1:Y_size
            temp = norm(X(i,:)-Y(j,:));
            if temp < min
                min = temp;
            end
        end
    end
end
%--------------------------------------------%