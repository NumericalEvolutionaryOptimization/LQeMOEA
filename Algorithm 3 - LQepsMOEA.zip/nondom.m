% [xn,yn,xd,yd] = nondom (x,y)


function[xn,yn,xd,yd,I] = nondom (x, y)
   n = length(y(:,1));
   I = ones(1,n);
   xd = [];
   yd = [];
   
   for i = 1:n,
      for j = i+1:n,
          dom = vdomw(y(j,:),y(i,:));
	  if dom==1,
	     I(i) = 0;
	  elseif dom==-1,
	     I(j) = 0;   
	  end
      end
   end
   
   ind  = 1;
   for i = 1:n,
     if I(i) == 1,
        xn(ind,:) = x(i,:);
	    yn(ind,:) = y(i,:);
	    ind = ind + 1;
    else
        xd(end+1,:) = x(i,:);
	      yd(end+1,:) = y(i,:);
     end
   end  	 
   

function[dom] =  vdomw (v,w)
  n = length(v);
  
  t = 0;  
  for i = 1:n,
    if v(i) ~= w(i)  
       t = 1;
       break;
    end
  end     
  if  t==0,
    dom = 0;  
    return;
  end  
  
  t=0;
  for i = 1:n,
    if v(i) < w(i) 
      t=1;
      break;
    end  
  end  
  if t==0 
    dom = -1;
    return;
  end     

  t=0;
  for i=1:n,
    if v(i) > w(i) 
      t=1;
      break;
    end  
  end  
  if  t==0,
    dom = 1;  
    return;
  end
    
  dom = 0;
       	  	      