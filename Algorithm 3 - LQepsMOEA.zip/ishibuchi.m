function Fx = ishibuchi(Fx, k, alpha)
    if nargin < 3
        alpha = 1e-10;
    end
    Fx = (1-alpha).*Fx + (alpha/k)*sum(Fx, 2);
end

