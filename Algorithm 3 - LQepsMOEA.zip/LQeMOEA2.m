classdef LQeMOEA2 < ALGORITHM
% <multi> <real/integer/label/binary/permutation> <constrained/none>
% LQeMOEA

%------------------------------- Reference --------------------------------
% K. Deb, A. Pratap, S. Agarwal, and T. Meyarivan, A fast and elitist
% multiobjective genetic algorithm: NSGA-II, IEEE Transactions on
% Evolutionary Computation, 2002, 6(2): 182-197.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2023 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Generate random population
            Population = Problem.Initialization();
            [~,FrontNo,CrowdDis] = EnvironmentalSelectionLQ(Population,Problem.N);
            Offspring = Population;
            dx = norm(Problem.upper-Problem.lower)/20;
            eps = ones(1,Problem.M)*.2;
            % Apply archiver                      
            [Ax, Ay, Nx, Ny, Dx, Dy] = archiving([], [], Population.decs, Population.objs, eps, dx, 1);

            flag = true;
            %% Optimization
            while Algorithm.NotTerminated(Population, Offspring)
                % Generate offspring
                if flag
                    MatingPool = TournamentSelection(2,Problem.N,FrontNo);
                    Offspring  = OperatorGA(Problem,Population(MatingPool));
                else                    
                    MatingPool1 = TournamentSelection(2, 2*round(size(Nx,1)/2), FrontNo1);                    
                    Offspring1  = OperatorGA(Problem,Pop1(MatingPool1));
                    if length(Offspring1) < Problem.N
                        MatingPool2 = TournamentSelection(2, Problem.N-2*round(size(Nx,1)/2), FrontNo2);
                        Offspring2  = OperatorGA(Problem,Pop2(MatingPool2));
                        Offspring = [Offspring1 Offspring2];
                    else
                        Offspring = Offspring1;                        
                    end
                end

                % Normalize population                
                Ox = Offspring.decs;
                Oy = Offspring.objs;

                % Apply archiver    
                [Ax, Ay, Nx, Ny, Dx, Dy] = archiving(Ax, Ay, Ox, Oy, eps, dx, size(Algorithm.result,1)+1);                

                % If archiver size is less than pop size
                if size(Ax,1) < size(Ox,1)
                %   Apply nondomsort on the rest                
                    [Population,FrontNo,CrowdDis] = EnvironmentalSelectionLQ([Population,Offspring],Problem.N);
                    flag = true;
                else
                    Population = SOLUTION(Ax, Ay, zeros(Problem.N,1));
                    Pop1 = SOLUTION(Nx, Ny, zeros(size(Nx,1),1));

                    if ~isempty(Dx)
                        Pop2 = SOLUTION(Dx, Dy, zeros(size(Dx,1),1));
                    else
                        Pop2 = [];
                    end

                    FrontNo = ones(Problem.N,1);
                    FrontNo1 = ones(size(Nx,1),1);
                    FrontNo2 = ones(size(Dx,1),1);

                    flag = false;
                end     
            end
        end
    end
end