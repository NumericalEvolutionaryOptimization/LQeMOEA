% ArchiveUpdateLQepsDNDClustX
 
function [Ax,Ay,Nx,Ny,Dx,Dy,Rx,Ry,I_N,I_D,I_R] = ArchiveUpdateLQepsDNDClustX(Ax0, Ay0, Px, Py,eps,delta_neigh,gensize,ND_size)
   Bx = [Ax0; Px];
   By = [Ay0; Py];
   
   D_size = gensize - ND_size;

   n = length(Bx(:,1));
   [Nx,Ny,Dx,Dy,I] = nondom(Bx,By);

   I_N = find(I==1);
   I_D = find(I==0);

   Ax = Nx;
   Ay = Ny;
   
   nn = length(Nx(:,1));
   
   if isempty(Dx) ~= 1
       nd = length(Dx(:,1));
       nd_flags = zeros(nd,1);
       %----MODIFICACION----% 
       Distance = inf(nd,n);
       neighb = cell(1,nd);
       for i=1:nd
           for j=1:n 
               distance = norm( Dx(i,:) - Bx(j,:) );
               if distance > 0
                   Distance(i,j) = distance;
               end
           end
       end
       for i=1:nd
           neighb{i} = find( Distance(i,:)<delta_neigh );
           %IMPORTANT! neighb{i} has Bx indices!
       end
       
       for i = 1:nd  
           flag = false;
           for j = 1:nn
               if dominance(Dy(i,:)-eps,Ny(j,:))
                   flag = true;
                   break;
               end
           end
           if (flag == false)
               continue;
           end 
           flag2 = true;
           for j = 1:length(neighb{i})
               if dominance(By(neighb{i}(j),:),Dy(i,:))
                   flag2 = false;
                   break
               end
           end
           if flag2 == true
               Ax(end+1,:) = Dx(i,:);
               Ay(end+1,:) = Dy(i,:);
               nd_flags(i) = 1;
           end
       end 
       

       %Selecting D and R:
       Rx = Dx(nd_flags==0,:);
       Ry = Dy(nd_flags==0,:);
       I_R = I_D(nd_flags==0);
       Dx = Dx(nd_flags==1,:);
       Dy = Dy(nd_flags==1,:);
       I_D = I_D(nd_flags==1);
       
        %REDUCTION TO gensize SIZE:
        if size(Ay,1) > gensize
            [ANx, ANy, ADx, ADy] = nondom(Ax,Ay);
    
            if size(ANy,1) < ND_size
                ND_size = size(ANy,1);
                D_size = gensize-ND_size;
            elseif size(ADy,1) < D_size
                D_size = size(ADy,1);
                ND_size = gensize-D_size;
            end
            [~,Med_ND,~,~,ND_indices] = kmedoids(ANx,ND_size);
            if D_size == 0
                Med_D = [];
                D_indices = [];
            elseif D_size == size(ADx,1)
                Med_D = ADx;
                D_indices = 1:D_size;
            else
                [~,Med_D,~,~,D_indices] = kmedoids(ADx,D_size);
            end

            removed_D_pts = setdiff(1:size(ADx,1),D_indices);
            removed_ND_pts = setdiff(1:size(ANx,1),ND_indices);
            %Changing points from D to R:
            for i=1:length(removed_D_pts)
                I = find(ismember(Dx,ADx(removed_D_pts(i),:),'rows'));
                Rx(end+1,:) = Dx(I(1),:);
                Ry(end+1,:) = Dy(I(1),:);
                I_R(end+1) = I_D(I(1));
                I_D(I(1)) = [];
                Dx(I(1),:) = [];
                Dy(I(1),:) = [];
            end
            %Changing points from N to R:
            for i=1:length(removed_ND_pts)
                I = find(ismember(Nx,ANx(removed_ND_pts(i),:),'rows'));
                Rx(end+1,:) = Nx(I(1),:);
                Ry(end+1,:) = Ny(I(1),:);
                I_R(end+1) = I_N(I(1));
                I_N(I(1)) = [];
                Nx(I(1),:) = [];
                Ny(I(1),:) = [];
            end
    
            %REDUCING TO gensize SIZE
            Ax = [];
            Ay = [];
            Ax(1:D_size,:) = Med_D;
            Ax(D_size+1:D_size+ND_size,:) = Med_ND;
            Ay(1:D_size,:) = ADy(D_indices,:);
            Ay(D_size+1:D_size+ND_size,:) = ANy(ND_indices,:);

            %IF REPEATED D MEDOIDS
            if size(unique(D_indices),1) ~= size(D_indices,1) 
                % Find unique elements and their counts
                [unique_elements, ~, idx] = unique(D_indices);
                counts = histc(idx, 1:numel(unique_elements));
                
                % Find repeated elements
                repeated_elements = unique_elements(counts > 1);
                
                for elem = 1:length(repeated_elements)
                    Dx(end+1,:) = ADx(repeated_elements(elem),:);
                    Dy(end+1,:) = ADy(repeated_elements(elem),:);
                    I = find(ismember(Bx,ADx(repeated_elements(elem),:),'rows'));
                    I_D(end+1) = I(1);
                end
            end
            %IF REPEATED ND MEDOIDS
            if size(unique(ND_indices),1) ~= size(ND_indices,1) 
                % Find unique elements and their counts
                [unique_elements, ~, idx] = unique(ND_indices);
                counts = histc(idx, 1:numel(unique_elements));
                
                % Find repeated elements
                repeated_elements = unique_elements(counts > 1);
                
                for elem = 1:length(repeated_elements)
                    Nx(end+1,:) = ANx(repeated_elements(elem),:);
                    Ny(end+1,:) = ANy(repeated_elements(elem),:);
                    I = find(ismember(Bx,ANx(repeated_elements(elem),:),'rows'));
                    I_N(end+1) = I(1);
                end
            end
        end
   else %ND = empty

        %Selecting D and R:
       Rx = [];
       Ry = [];
       I_R = [];
       I_D = [];
       Dx = [];
       Dy = [];
                       
        %REDUCTION TO gensize SIZE:
        if size(Ay,1) > gensize
            [~,~,~,~,ND_indices] = kmedoids(Ax,gensize);  

            removed_ND_pts = setdiff(1:size(Ax,1),ND_indices);
            %Changing points from N to R:
            for i=1:length(removed_ND_pts)
                I = find(ismember(Nx,Ax(removed_ND_pts(i),:),'rows'));
                Rx(end+1,:) = Nx(I(1),:);
                Ry(end+1,:) = Ny(I(1),:);
                I_R(end+1) = I_N(I(1));
                I_N(I(1)) = [];
                Nx(I(1),:) = [];
                Ny(I(1),:) = [];
            end
    
            %REDUCING TO gensize SIZE
            Ax = Ax(ND_indices,:);
            Ay = Ay(ND_indices,:);

            %IF REPEATED ND MEDOIDS
            if size(unique(ND_indices),1) ~= size(ND_indices,1) 
                % Find unique elements and their counts
                [unique_elements, ~, idx] = unique(ND_indices);
                counts = histc(idx, 1:numel(unique_elements));
                
                % Find repeated elements
                repeated_elements = unique_elements(counts > 1);
                
                for elem = 1:length(repeated_elements)
                    Nx(end+1,:) = Ax(repeated_elements(elem),:);
                    Ny(end+1,:) = Ay(repeated_elements(elem),:);
                    I = find(ismember(Bx,Ax(repeated_elements(elem),:),'rows'));
                    I_N(end+1) = I(1);
                end
            end
        end
   end

end