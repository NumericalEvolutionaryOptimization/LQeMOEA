% ArchiveUpdatePQeps_c
 
function [Ax,Ay,Nx,Ny] = ArchiveUpdatePQeps_c (Ax0, Ay0, Px, Py,eps,delta_neigh)
   Bx = [Ax0; Px];
   By = [Ay0; Py];

   %----MODIFICACION----%
   n = length(Bx(:,1));
   %AÑADI I AL FINAL
   [Nx, Ny, Dx, Dy, ~] = nondom(Bx,By);
   %--FIN MODIFICACION--%
   
%    scatter(Ny(:,1),Ny(:,2),'ko');
   

   Ax = Nx;
   Ay = Ny;
   
   nn = length(Nx(:,1));
   
   if isempty(Dx) ~= 1
       nd = length(Dx(:,1));
       %----MODIFICACION----% 
       Distance = inf(nd,n);
       neighb = cell(1,nd);
       for i=1:nd
           for j=1:n %modificación:j=1, en vez de j=i
               distance = norm( Dx(i,:) - Bx(j,:) );
               if distance > 0
                   Distance(i,j) = distance;
               end
           end
       end
       for i=1:nd
           neighb{i} = find( Distance(i,:)<delta_neigh );
           %IMPORTANT! neighb{i} has Bx indices!
       end
       %--FIN MODIFICACION--%
       
       for i = 1:nd  
           %----MODIFICACION----%  
           flag = false;
           %--FIN MODIFICACION--%
           for j = 1:nn
               if dominance(Dy(i,:)-eps,Ny(j,:))
                   %----MODIFICACION----%
                   flag = true;
                   %--FIN MODIFICACION--%
                   break;
               end
           end
           %IMPORTANT!!! COMMENT WHOLE "IF" WHEN "NOT NQEPS"!!
           if (flag == false)
               continue;
           end 
           %----MODIFICACION----%
           flag2 = true;
           for j = 1:length(neighb{i})
               if dominance(By(neighb{i}(j),:),Dy(i,:))
                   flag2 = false;
                   break
               end
           end
           if flag2 == true
               Ax(end+1,:) = Dx(i,:);
               Ay(end+1,:) = Dy(i,:);
           end
           %--FIN MODIFICACION--%
       end 
   end
   