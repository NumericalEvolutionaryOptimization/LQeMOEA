function I_acc_val = I_acc(Px,Py,plat_problem)
    
    num_objs = size(Py,2);
    num_decs = size(Px,2);
    num_pts = size(Py,1);
    norm_q_PT = zeros(1,num_pts);
    
    for pt=1:num_pts
%         disp([int2str(pt) '/' int2str(num_pts)])
        X = Px(pt,:);
        Y = Py(pt,:);
            %Compute Jacobian
            h = 1e-12;
            for i=1:num_decs
                Ax_h = X;
                Ax_h(i) = X(i) + h; % x+h*ei
                if ~ischar(plat_problem) %FOR MPM2 PROBLEMS
                    PRO = @MPM2;
                    input = plat_problem(2:end);
                    ProblemX     = PRO(input{:});
                    Ay_h = ProblemX.CalObj(Ax_h);
                else
                    eval(['Ay_h = CalObj(' plat_problem ',Ax_h);'])
                end
                J(:,i) = (Ay_h-Y)/h;
            end
        %Compute Jacobian Platemo
%         eval(['J = CalObjGrad(' plat_problem ',X);'])

        %QuadProg Parameters
        H = J*J';
        f = zeros([1,num_objs]);
        A = [];
        b = [];
        Aeq = ones([1,num_objs]);
        beq = 1;
        lb = zeros([1,num_objs]);
        ub = ones([1,num_objs]);
        alpha0 = 0.5*ones([1,num_objs]);
        %QuadProg
        options = optimoptions('quadprog', 'Display', 'off');
        if isempty(find(isnan(J),1))
            alpha = quadprog(H,f,A,b,Aeq,beq,lb,ub,alpha0,options);
            %KKT Value
            q = J'*alpha;
            norm_q_PT(pt) = norm(q); 
        else
            continue
        end
    end
    I_acc_val = mean(norm_q_PT);
end