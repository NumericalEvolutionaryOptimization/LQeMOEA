function [value] = b_poly(y, a)
% a > 0.
% a ~= 1.

% Copyright (c) 2018 Adanay Mart�n & Oliver Sch�tze.
% This file is subject to the terms and conditions defined in
% the file 'LICENSE.txt', which is part of this source code package.

value = power(y, a);
end

