Notes: These notes may be not updated.

- PT behaves well for all ZDT except ZDT6.
- ZDT3 is disconnected but PT behaves acceptable for the case.