Notes: These notes may be not updated.

All WFG functions are challenging for PT. The tests are done with a small 
number of variables as it gets slow for a great number of variables. Main 
difficulties are due to:
- Small changes in decision space causes big changes in objective space.
- Indefinitions in derivatives lead to predictors near to orthogonal to the 
  PS which lead to the computation of several correctors. 