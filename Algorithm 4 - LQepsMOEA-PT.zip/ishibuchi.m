function [Ix,Iy] = ishibuchi(Ax,Ay,alpha)
    %ISHIBUCHI
    num_obj = size(Ay,2);
    Iy = (1-alpha).*Ay+(alpha/num_obj)*sum(Ay,2);
    Ix = Ax;
end