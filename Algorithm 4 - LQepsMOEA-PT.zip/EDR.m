function [B] = EDR(Ay, Px, Py, dx, dy, lb)
    %dx y dy son escalares
    %dx = norm(Pro.upper-Pro.lower)/20;
    %dy = 0.2;

    Pz = zeros(size(Px));    
    for i=1:size(Px,1)
        Pz(i,:) = xtoz(Px(i,:), dx, lb);        
    end
    [C,ia,ic] = unique(Pz,'rows');   

    % Compute all distances
    Dy = pdist2(Ay, Py,"euclidean");

    % Select those less than delta
    Dy = (Dy<dy);        % Check details

    % Compute indicator
    cnt = 0;
    for i=1:size(Dy,1)
        cnt = cnt + size(unique(Pz(Dy(i,:),:), 'rows'),1);
    end

    B = cnt/size(Ay,1);
end

function z = xtoz(xd, h, lb)
    z = round((xd - lb) ./ h + 1/2); %Compute cell
end