clearvars
close all

popsize = 100;
iters = 50;
maxFE = popsize*iters;
num_runs = 20;
base_names = {'MMMOP','MMMOP2','TMOP','NPQe','MMF'};
start_num = {1,1,1,0,1};
end_num = {6,6,4,5,8};

alpha = 0.02;
eps_percent = 0.2;
delta = 20;
dy = 0.2;
r_percent = 0.10;
minpts = 3;

%Parameters for 3D tau estimation:
k_nn = 10;

for testsuit=1:size(base_names,2)
% for testsuit=3:3
    for run=1:num_runs
    % for run=14:14
        for prob_num=start_num{testsuit}:end_num{testsuit}
        % for prob_num=1:1
            disp([base_names{testsuit} int2str(prob_num) '_run' int2str(run)])

            eval(['prob_plat = ' base_names{testsuit} int2str(prob_num) ';'])
            upper = prob_plat.upper;
            lower = prob_plat.lower;
            num_dec = prob_plat.D;
            num_obj = prob_plat.M;
            
            problem = [base_names{testsuit} int2str(prob_num)];
            plat_problem = [base_names{testsuit} int2str(prob_num)];
            Ry = GetPF(prob_plat);
            mu = 100;
            % r_dbscan = 0.25;
            r_uplow = r_percent*max(upper-lower);
            dist = 'chebychev';    
        
            i=50;

            load([pwd '/LQepsMOEAPT/' problem '_Archiver_' int2str(i) '_run' int2str(run) '.mat'],'Ax','Ay')
            [Nx, Ny, Dx, Dy, I_nd] = nondom(Ax,Ay);
            %-----------NON DOMINATED COMPONENT DETECTION------------------------%
        %     r = r_dbscan*mean(pdist(Nx)); %radius is 10% of the average of all the distances
            idx_nd = dbscan(Nx,r_uplow,minpts,'Distance','chebychev');
            num_ndcomp = max(idx_nd);
            %---------------DOMINATED COMPONENT DETECTION------------------------%
            if ~isempty(Dx)
                idx_d = dbscan(Dx,r_uplow,minpts,'Distance','chebychev');
                num_dcomp = max(idx_d);
            else
                idx_d = [];
                num_dcomp = -1;
            end
            
                                
            %CORREGIR PARA 3D
            if num_obj>2
                if size(Nx,1)>= popsize
                    [~,~,~,~,midx] = kmedoids(Nx,popsize);
                    component_midx = idx_nd(midx);
                end
                figure
%                 scatter3(Nx(:,1),Nx(:,2),Nx(:,3),'filled')
%                 hold on
                scatter3(Nx(midx,1),Nx(midx,2),Nx(midx,3),'filled')
                hold on
                tau_comp = [];
                for comp = 1:num_ndcomp
                    comp_I = midx(component_midx == comp);
%                     X = Nx(comp_I,:);
%                     Y = Ny(comp_I,:);
                    scatter3(Nx(comp_I,1),Nx(comp_I,2),Nx(comp_I,3),'.')
                    tau_comp(end+1) = estimate_tau(Ny(comp_I,:),k_nn);
                end
                load([pwd '/LQepsMOEAPT/' problem '_num_ND_comp_' int2str(i) '_run' int2str(run) '.mat'],'num_ndcomp')
                load([pwd '/LQepsMOEAPT/' problem '_num_D_comp_' int2str(i) '_run' int2str(run) '.mat'],'num_dcomp')
                tau = mean(tau_comp)/(num_dcomp+num_ndcomp);
                disp(tau)
                save([pwd '/LQepsMOEAPT/' problem '_tau_' int2str(i) '_run' int2str(run) '.mat'],'tau')
            end           
        end
    end
end

function tau = estimate_tau(Y,k)
    tau_vec = ones(1,size(Y,1));
    for i=1:size(Y,1)
        yi = Y(i,:);
        [~, dist] = knnsearch(Y, Y(i,:), 'K', k+1);
%         idx(1) = [];
        dist(1) = [];
        tau_vec(i) = mean(dist);
    end
    tau = mean(tau_vec);%/size(Y,1);
end