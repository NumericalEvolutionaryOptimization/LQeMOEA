clearvars
close all

% %MPM2 names
% p = ["MPM2,2,2,2,'funnel'";...
%     "MPM2,2,2,2,'random'";...
%     "MPM2,2,2,32,'funnel'";...
%     "MPM2,2,2,32,'random'";...
%     "MPM2,2,2,8,'funnel'";...
%     "MPM2,2,2,8,'random'";...
%     "MPM2,2,3,2,'funnel'";...
%     "MPM2,2,3,2,'random'";...
%     "MPM2,2,3,32,'funnel'";...
%     "MPM2,2,3,32,'random'";...
%     "MPM2,2,3,8,'funnel'";...
%     "MPM2,2,3,8,'random'";...
%     "MPM2,2,5,2,'funnel'";...
%     "MPM2,2,5,2,'random'";...
%     "MPM2,2,5,32,'funnel'";...
%     "MPM2,2,5,32,'random'";...
%     "MPM2,2,5,8,'funnel'";...
%     "MPM2,2,5,8,'random'"];


popsize = 100;
iters = 50;
maxFE = popsize*iters;
num_runs = 20;
% base_names = {'MMMOP','MMMOP2','TMOP','NPQe','MMF','MPM2'};
% start_num = {1,1,1,0,1,1};
% end_num = {6,6,4,5,8,size(p,1)};
base_names = {'MMMOP','MMMOP2','TMOP','NPQe','MMF'};
start_num = {1,1,1,0,1};
end_num = {6,6,4,5,8};


alpha = 0.02;
eps_percent = 0.2;
delta = 20;
dy = 0.2;
r_percent = 0.10;
minpts = 3;

%Parameters for 3D tau estimation:
k_nn = 10;

%Counter for MPM problems
mpm_count = -1;

for testsuit=1:size(base_names,2)
% for testsuit=4:4
    for run=1:num_runs
    % for run=9:num_runs
        for prob_num=start_num{testsuit}:end_num{testsuit}
        % for prob_num=5:5
            mpm_count = mpm_count + 1;
            
            if strcmp(base_names{testsuit},'MPM2')
                prob_plat = eval(strcat('{',p(mod(mpm_count,size(p,1))+1),'}'));
                disp(['MPM #' int2str(mod(prob_num-1,size(p,1))+1)]);
                disp([p(mod(mpm_count,size(p,1))+1) "_run" int2str(run)])
                objdec = char(p(mod(mpm_count,size(p,1))+1));
                prob_properties = split(objdec,',');
                num_obj = 2;
                seed = prob_properties{2};
                num_dec = str2double(prob_properties{3});
                num_peaks = prob_properties{4};
                topolo = prob_properties{5};
                topolo = topolo(2:end-1);
                lower    = zeros(1, num_dec)-0.2;
                upper    = zeros(1, num_dec)+1.2;
%                 load(['C:\Users\Angel Rodríguez\AppData\Roaming\MathWorks\MATLAB Add-Ons\Collections\PlatEMO\PlatEMO\Data\LQeMOEA2\LQeMOEA2_' base_names{testsuit} '_M' int2str(num_obj) '_D' int2str(num_dec) '_' int2str(prob_num) '.mat'])
                load(['C:\Users\angel\AppData\Roaming\MathWorks\MATLAB Add-Ons\Collections\PlatEMO\PlatEMO\Data\LQeMOEA2\LQeMOEA2_' base_names{testsuit} '_M' int2str(num_obj) '_D' int2str(num_dec) '_' int2str(mpm_count) '.mat'])
%                 load(['/home/nume/MATLAB Add-Ons/Collections/PlatEMO/Data/LQeMOEA2/LQeMOEA2_' base_names{testsuit} '_M' int2str(num_obj) '_D' int2str(num_dec) '_' int2str(prob_num) '.mat'])
                problem = p(mod(mpm_count,size(p,1))+1);
                problem = sprintf('''%s''', problem);
                problem = problem(2:end-1);
                plat_problem = prob_plat;
                Ry = readmatrix(['C:\Users\angel\AppData\Roaming\MathWorks\MATLAB Add-Ons\Collections\PlatEMO\PlatEMO\Problems\Multi-objective optimization\MPM\ref\' int2str(num_dec) 'd-' topolo '-' num_peaks 'p-' seed '-ref.csv_dy0.05.csv']);
%                 Ry = readmatrix(['C:\Users\Angel Rodríguez\AppData\Roaming\MathWorks\MATLAB Add-Ons\Collections\PlatEMO\PlatEMO\Problems\Multi-objective optimization\MPM\ref\' int2str(num_dec) 'd-' topolo '-' num_peaks 'p-' seed '-ref.csv_dy0.05.csv']);
            else
                eval(['prob_plat = ' base_names{testsuit} int2str(prob_num) ';'])
                disp([base_names{testsuit} int2str(prob_num) '_run' int2str(run)])
                upper = prob_plat.upper;
                lower = prob_plat.lower;
                num_dec = prob_plat.D;
                num_obj = prob_plat.M;
%                 load(['C:\Users\Angel Rodríguez\AppData\Roaming\MathWorks\MATLAB Add-Ons\Collections\PlatEMO\PlatEMO\Data\LQeMOEA2\LQeMOEA2_' base_names{testsuit} int2str(prob_num) '_M' int2str(num_obj) '_D' int2str(num_dec) '_' int2str(run) '.mat'])
                load(['C:\Users\angel\AppData\Roaming\MathWorks\MATLAB Add-Ons\Collections\PlatEMO\PlatEMO\Data\LQeMOEA2\LQeMOEA2_' base_names{testsuit} int2str(prob_num) '_M' int2str(num_obj) '_D' int2str(num_dec) '_' int2str(run) '.mat'])
%                 load(['/home/nume/MATLAB Add-Ons/Collections/PlatEMO/Data/LQeMOEA2/LQeMOEA2_' base_names{testsuit} int2str(prob_num) '_M' int2str(num_obj) '_D' int2str(num_dec) '_' int2str(run) '.mat'])
                problem = [base_names{testsuit} int2str(prob_num)];
                plat_problem = [base_names{testsuit} int2str(prob_num)];
                Ry = GetPF(prob_plat);
            end
            

            Ax = [];
            Ay = [];
    %         alpha = 0.02;
            eps = eps_percent*ones(1,num_obj);
    %         delta = 20;
            dx = norm(upper-lower)/20;
    %         dy = 0.2;
            delta_neigh = sqrt(sum((upper - lower).^2)) / delta;
            mu = 100;
            % r_dbscan = 0.25;
            r_uplow = r_percent*max(upper-lower);
            dist = 'chebychev';
            ishi = true;
        
        
            for i=1:iters
                disp(['    Archiving... Gen ' int2str(i) '/' int2str(iters)])
                Px = result{i,3}.decs;
                Py = result{i,3}.objs;
        
                %NORMALIZATION:
                Ay2 = Ay;
                Py2 = Py;
                if ~isempty(Ax)
                    Ay2 = (Ay-min(Ay))./(max(Ay)-min(Ay));
                    Py2 = (Py-min(Ay))./(max(Ay)-min(Ay));
                end
                %END NORMALIZATION
        
                %ISHIBUCHI
                if ishi
                    [Px,Py] = ishibuchi(Px,Py,alpha);
                end
                %END ISHIBUCHI
        
                %ARCHIVING
                [Ax,Ay2] = ArchiveUpdatePQeps_c(Ax,Ay2,Px,Py2,eps,delta_neigh);
                if ~strcmp(base_names{testsuit},'MPM2')
                    eval(['Ay = CalObj(' plat_problem ',Ax);'])
                else
                    PRO = @MPM2;
                    input = plat_problem(2:end);
                    ProblemX     = PRO(input{:});
                    Ay = ProblemX.CalObj(Ax);
                end
                %END ARCHIVING
        
                figure(Visible="off")
                scatter(Ax(:,1),Ax(:,2))
                saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_Ax_iter' int2str(i) '_run' int2str(run) '.png'])
                figure(Visible="off")
                scatter(Ay(:,1),Ay(:,2))
                hold on
                scatter(Ry(:,1),Ry(:,2),'.')
                saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_Ay_iter' int2str(i) '_run' int2str(run) '.png'])
                close all    
        
                if i==50
                    disp('    ----------------------    ')
                    [Nx, Ny, Dx, Dy, I_nd] = nondom(Ax,Ay);
                    %-----------NON DOMINATED COMPONENT DETECTION------------------------%
                %     r = r_dbscan*mean(pdist(Nx)); %radius is 10% of the average of all the distances
                    idx_nd = dbscan(Nx,r_uplow,minpts,'Distance','chebychev');
                    num_ndcomp = max(idx_nd);
                    %---------------DOMINATED COMPONENT DETECTION------------------------%
                    if ~isempty(Dx)
                        idx_d = dbscan(Dx,r_uplow,minpts,'Distance','chebychev');
                        num_dcomp = max(idx_d);
                    else
                        idx_d = [];
                        num_dcomp = -1;
                    end
                    
                    if size(Ax,1) < 20
                        disp('    ¡¡¡¡¡¡ Archiver Size < 20 !!!!!!')
                        
                        %-----------NON DOMINATED x0 Selection------------------------%
                        k = min(size(Nx,1),4);
                        plot_comp = num_ndcomp;
                        if plot_comp == -1
                            plot_comp = 1;
                        end
                        disp(['    Num ND Comp = ' int2str(num_ndcomp)])
                        figure(100)
                        markerTypes = repmat('o', 1, plot_comp+1);
                        if ~isempty(find(idx_nd == -1,1))
                            markerTypes(1) = 'x';
                        end
                        gscatter(Nx(:,1),Nx(:,2),idx_nd,[],markerTypes,'filled');
                        hold on
                        legend('Location','northeastoutside')
                        title('Non-Dominated Components (Dec. Space)')
                        figure(101)
                        gscatter(Ny(:,1),Ny(:,2),idx_nd,[],markerTypes,'filled');
                        hold on
                        scatter(Ry(:,1),Ry(:,2),'.')
                        legend('Location','northeastoutside')
                        title('Non-Dominated Components (Obj. Space)')
                        comp_total_length = NaN;
                        for comp=1:k
                            save([pwd '/LQepsMOEAPT/' problem '_length_ND_iter' int2str(i) '_comp' int2str(comp) '_run' int2str(run) '.mat'],'comp_total_length')
                        end
                        total_length_nondom = NaN;
                        [~,~,~,~,midx] = kmedoids(Nx,k);
                        for startpoint=1:k
                            x0 = Nx(midx(startpoint),:);
                            y0 = Ny(midx(startpoint),:);
                            figure(100)
                            scatter(x0(:,1),x0(:,2),'md','filled')
                            figure(101)
                            scatter(y0(:,1),y0(:,2),'cd','filled')
                            save([pwd '/LQepsMOEAPT/' problem '_x0_ND_iter' int2str(i) '_comp' int2str(startpoint) '_run' int2str(run) '.mat'],'x0')
                        end
                        figure(100)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_NDxComps_iter' int2str(i) '_run' int2str(run) '.png'])
                        figure(101)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_NDyComps_iter' int2str(i) '_run' int2str(run) '.png'])
                        %-----------DOMINATED x0 Selection------------------------%
                        if ~isempty(Dx)
                            k = min(size(Dx,1),4);
                            plot_comp = num_dcomp;
                            if plot_comp == -1
                                plot_comp = 1;
                            end
                            disp(['    Num D Comp = ' int2str(num_dcomp)])
                            figure(102)
                            markerTypes = repmat('o', 1, plot_comp+1);
                            if ~isempty(find(idx_d == -1,1))
                                markerTypes(1) = 'x';
                            end
                            gscatter(Dx(:,1),Dx(:,2),idx_d,[],markerTypes,'filled');
                            hold on
                            legend('Location','northeastoutside')
                            title('Dominated Components (Dec. Space)')
                            figure(103)
                            gscatter(Dy(:,1),Dy(:,2),idx_d,[],markerTypes,'filled');
                            hold on
                            legend('Location','northeastoutside')
                            title('Dominated Components (Obj. Space)')
                            comp_total_length = NaN;
                            for comp=1:k
                                save([pwd '/LQepsMOEAPT/' problem '_length_D_iter' int2str(i) '_comp' int2str(comp) '_run' int2str(run) '.mat'],'comp_total_length')
                            end
                            total_length_dom = NaN;
                            [~,~,~,~,midx] = kmedoids(Dx,k);
                            for startpoint=1:k
                                x0 = Dx(midx(startpoint),:);
                                y0 = Dy(midx(startpoint),:);
                                figure(102)
                                scatter(x0(:,1),x0(:,2),'md','filled')
                                figure(103)
                                scatter(y0(:,1),y0(:,2),'cd','filled')
                                save([pwd '/LQepsMOEAPT/' problem '_x0_D_iter' int2str(i) '_comp' int2str(startpoint) '_run' int2str(run) '.mat'],'x0')
                            end
                        end
                        figure(102)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_DxComps_iter' int2str(i) '_run' int2str(run) '.png'])
                        figure(103)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_DyComps_iter' int2str(i) '_run' int2str(run) '.png'])
                
                        disp('    ND Length = NaN')
                        disp('    D Length = NaN')
                
                        tau = 0.01;
                        
                        num_ndcomp = k;
                        num_dcomp = k;
                        save([pwd '/LQepsMOEAPT/' problem '_tau_' int2str(i) '_run' int2str(run) '.mat'],'tau')
                        save([pwd '/LQepsMOEAPT/' problem '_Archiver_' int2str(i) '_run' int2str(run) '.mat'],'Ax','Ay')
                        save([pwd '/LQepsMOEAPT/' problem '_num_ND_comp_' int2str(i) '_run' int2str(run) '.mat'],'num_ndcomp')
                        save([pwd '/LQepsMOEAPT/' problem '_num_D_comp_' int2str(i) '_run' int2str(run) '.mat'],'num_dcomp')
                    elseif num_dcomp + num_ndcomp <= 4 %If few components, use k-means with k=4 (total 8 components)
                        % Actually, k=min(|Nx|,4) and k = min(|Dx|,4); so it can be less than 4.
                        %-----------NON DOMINATED x0 Selection------------------------%
                        k = min(size(Nx,1),4);
                        plot_comp = num_ndcomp;
                        if plot_comp == -1
                            plot_comp = 1;
                        end
                        disp(['    Num ND Comp = ' int2str(num_ndcomp)])
                        figure(100)
                        markerTypes = repmat('o', 1, plot_comp+1);
                        if ~isempty(find(idx_nd == -1,1))
                            markerTypes(1) = 'x';
                        end
                        gscatter(Nx(:,1),Nx(:,2),idx_nd,[],markerTypes,'filled');
                        hold on
                        legend('Location','northeastoutside')
                        title('Non-Dominated Components (Dec. Space)')
                        figure(101)
                        gscatter(Ny(:,1),Ny(:,2),idx_nd,[],markerTypes,'filled');
                        hold on
                        scatter(Ry(:,1),Ry(:,2),'.')
                        legend('Location','northeastoutside')
                        title('Non-Dominated Components (Obj. Space)')
                        total_length_nondom = 0;
                        for comp = 1:num_ndcomp
                            X = Nx(idx_nd==comp,:);
                            Y = Ny(idx_nd==comp,:);
                            n = size(Y,1);
                            Points = sortrows(Y,1);
                            endpoints = [Points(1,:); Points(end,:)];
                            distances = zeros(1,n-1);
                            points_p_segment = zeros(1,n-1);
                            for j=1:n-1
                                distances(j) = norm(Points(j+1,:)-Points(j,:));
                            end
                            total_length_nondom = total_length_nondom + sum(distances); %SUM OF THE LENGTH SEGMENTS
                            comp_total_length = sum(distances);
                            save([pwd '/LQepsMOEAPT/' problem '_length_ND_iter' int2str(i) '_comp' int2str(comp) '_run' int2str(run) '.mat'],'comp_total_length')
                        end
                        X = Nx(idx_nd~=-1,:); %remove outliers for kmeans
                        Y = Ny(idx_nd~=-1,:);
                        if size(X,1)<k
                            X = Nx;
                            Y = Ny;
                        end
                        [~,~,~,~,midx] = kmedoids(X,k);
                        for startpoint=1:k
                            x0 = X(midx(startpoint),:);
                            y0 = Y(midx(startpoint),:);
                            figure(100)
                            scatter(x0(:,1),x0(:,2),'md','filled')
                            figure(101)
                            scatter(y0(:,1),y0(:,2),'cd','filled')
                            save([pwd '/LQepsMOEAPT/' problem '_x0_ND_iter' int2str(i) '_comp' int2str(startpoint) '_run' int2str(run) '.mat'],'x0')
                        end
                        figure(100)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_NDxComps_iter' int2str(i) '_run' int2str(run) '.png'])
                        figure(101)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_NDyComps_iter' int2str(i) '_run' int2str(run) '.png'])
                        num_ndcomp = k;
                        %-----------DOMINATED x0 Selection------------------------%
                        k = min(size(Dx,1),4);
                        if ~isempty(Dx)
                    %     r = r_dbscan*mean(pdist(Dx)); %radius is 10% of the average of all the distances
                    %     idx = dbscan(Dx,r_uplow,minpts);
    %                     idx_d = dbscan(Dx,r_uplow,minpts,'Distance','chebychev');
    %                     num_dcomp = max(idx_d);
                        plot_comp = num_dcomp;
                        if plot_comp == -1
                            plot_comp = 1;
                        end
                        disp(['    Num D Comp = ' int2str(num_dcomp)])
                        figure(102)
                        markerTypes = repmat('o', 1, plot_comp+1);
                        if ~isempty(find(idx_d == -1,1))
                            markerTypes(1) = 'x';
                        end
                        gscatter(Dx(:,1),Dx(:,2),idx_d,[],markerTypes,'filled');
                        hold on
                        legend('Location','northeastoutside')
                        title('Dominated Components (Dec. Space)')
                        figure(103)
                        gscatter(Dy(:,1),Dy(:,2),idx_d,[],markerTypes,'filled');
                        hold on
                        legend('Location','northeastoutside')
                        title('Dominated Components (Obj. Space)')
                        total_length_dom = 0;
                        for comp = 1:num_dcomp
                            X = Dx(idx_d==comp,:);
                            Y = Dy(idx_d==comp,:);
                            n = size(Y,1);
                            Points = sortrows(Y,1);
                            endpoints = [Points(1,:); Points(end,:)];
                            distances = zeros(1,n-1);
                            points_p_segment = zeros(1,n-1);
                            for j=1:n-1
                                distances(j) = norm(Points(j+1,:)-Points(j,:));
                            end
                            total_length_dom = total_length_dom + sum(distances); %SUM OF THE LENGTH SEGMENTS
                            comp_total_length = sum(distances);
                            save([pwd '/LQepsMOEAPT/' problem '_length_D_iter' int2str(i) '_comp' int2str(comp) '_run' int2str(run) '.mat'],'comp_total_length')
                        end
                        X = Dx(idx_d~=-1,:); %remove outliers for kmeans
                        Y = Dy(idx_d~=-1,:);
                        if size(X,1)<k
                            X = Dx;
                            Y = Dy;
                        end
                        [~,~,~,~,midx] = kmedoids(X,k);
                        for startpoint=1:k
                            x0 = X(midx(startpoint),:);
                            y0 = Y(midx(startpoint),:);
                            figure(102)
                            scatter(x0(:,1),x0(:,2),'md','filled')
                            figure(103)
                            scatter(y0(:,1),y0(:,2),'cd','filled')
                            save([pwd '/LQepsMOEAPT/' problem '_x0_D_iter' int2str(i) '_comp' int2str(startpoint) '_run' int2str(run) '.mat'],'x0')
                        end
                        end
                        figure(102)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_DxComps_iter' int2str(i) '_run' int2str(run) '.png'])
                        figure(103)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_DyComps_iter' int2str(i) '_run' int2str(run) '.png'])
                
                        disp(['    ND Length = ' num2str(total_length_nondom)])
                        disp(['    D Length = ' num2str(total_length_dom)])
                
                        tau = total_length_nondom/mu;
                        
                        num_dcomp = k;
                        save([pwd '/LQepsMOEAPT/' problem '_tau_' int2str(i) '_run' int2str(run) '.mat'],'tau')
                        save([pwd '/LQepsMOEAPT/' problem '_Archiver_' int2str(i) '_run' int2str(run) '.mat'],'Ax','Ay')
                        save([pwd '/LQepsMOEAPT/' problem '_num_ND_comp_' int2str(i) '_run' int2str(run) '.mat'],'num_ndcomp')
                        save([pwd '/LQepsMOEAPT/' problem '_num_D_comp_' int2str(i) '_run' int2str(run) '.mat'],'num_dcomp')
                    elseif num_dcomp + num_ndcomp <= 10 %If good amount of components
                        %-----------NON DOMINATED x0 Selection------------------------%
                        plot_comp = num_ndcomp;
                        if plot_comp == -1
                            plot_comp = 1;
                        end
                        disp(['    Num ND Comp = ' int2str(num_ndcomp)])
                        figure(100)
                        markerTypes = repmat('o', 1, plot_comp+1);
                        if ~isempty(find(idx_nd == -1,1))
                            markerTypes(1) = 'x';
                        end
                        gscatter(Nx(:,1),Nx(:,2),idx_nd,[],markerTypes,'filled');
                        hold on
                        legend('Location','northeastoutside')
                        title('Non-Dominated Components (Dec. Space)')
                        figure(101)
                        gscatter(Ny(:,1),Ny(:,2),idx_nd,[],markerTypes,'filled');
                        hold on
                        scatter(Ry(:,1),Ry(:,2),'.')
                        legend('Location','northeastoutside')
                        title('Non-Dominated Components (Obj. Space)')
                        total_length_nondom = 0;
                        for comp = 1:num_ndcomp
                            X = Nx(idx_nd==comp,:);
                            Y = Ny(idx_nd==comp,:);
                            n = size(Y,1);
                            Points = sortrows(Y,1);
                            endpoints = [Points(1,:); Points(end,:)];
                            distances = zeros(1,n-1);
                            points_p_segment = zeros(1,n-1);
                            for j=1:n-1
                                distances(j) = norm(Points(j+1,:)-Points(j,:));
                            end
                            total_length_nondom = total_length_nondom + sum(distances); %SUM OF THE LENGTH SEGMENTS
                            comp_total_length = sum(distances);
                            [~,~,~,~,midx] = kmedoids(X,1);
                            x0 = X(midx,:);
                            y0 = Y(midx,:);
                            figure(100)
                            scatter(x0(:,1),x0(:,2),'md','filled')
                            figure(101)
                            scatter(y0(:,1),y0(:,2),'cd','filled')
                            save([pwd '/LQepsMOEAPT/' problem '_length_ND_iter' int2str(i) '_comp' int2str(comp) '_run' int2str(run) '.mat'],'comp_total_length')
                            save([pwd '/LQepsMOEAPT/' problem '_x0_ND_iter' int2str(i) '_comp' int2str(comp) '_run' int2str(run) '.mat'],'x0')
                        end
                        figure(100)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_NDxComps_iter' int2str(i) '_run' int2str(run) '.png'])
                        figure(101)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_NDyComps_iter' int2str(i) '_run' int2str(run) '.png'])
                        %-----------DOMINATED x0 Selection------------------------%
                        if ~isempty(Dx)
                    %     r = r_dbscan*mean(pdist(Dx)); %radius is 10% of the average of all the distances
                    %     idx = dbscan(Dx,r_uplow,minpts);
    %                     idx_d = dbscan(Dx,r_uplow,minpts,'Distance','chebychev');
    %                     num_dcomp = max(idx_d);
                        plot_comp = num_dcomp;
                        if plot_comp == -1
                            plot_comp = 1;
                        end
                        disp(['    Num D Comp = ' int2str(num_dcomp)])
                        figure(102)
                        markerTypes = repmat('o', 1, plot_comp+1);
                        if ~isempty(find(idx_d == -1,1))
                            markerTypes(1) = 'x';
                        end
                        gscatter(Dx(:,1),Dx(:,2),idx_d,[],markerTypes,'filled');
                        hold on
                        legend('Location','northeastoutside')
                        title('Dominated Components (Dec. Space)')
                        figure(103)
                        gscatter(Dy(:,1),Dy(:,2),idx_d,[],markerTypes,'filled');
                        hold on
                        legend('Location','northeastoutside')
                        title('Dominated Components (Obj. Space)')
                        total_length_dom = 0;
                        for comp = 1:num_dcomp
                            X = Dx(idx_d==comp,:);
                            Y = Dy(idx_d==comp,:);
                            n = size(Y,1);
                            Points = sortrows(Y,1);
                            endpoints = [Points(1,:); Points(end,:)];
                            distances = zeros(1,n-1);
                            points_p_segment = zeros(1,n-1);
                            for j=1:n-1
                                distances(j) = norm(Points(j+1,:)-Points(j,:));
                            end
                            total_length_dom = total_length_dom + sum(distances); %SUM OF THE LENGTH SEGMENTS
                            comp_total_length = sum(distances);
                            [~,~,~,~,midx] = kmedoids(X,1);
                            x0 = X(midx,:);
                            y0 = Y(midx,:);
                            figure(102)
                            scatter(x0(:,1),x0(:,2),'md','filled')
                            figure(103)
                            scatter(y0(:,1),y0(:,2),'cd','filled')
                            save([pwd '/LQepsMOEAPT/' problem '_length_D_iter' int2str(i) '_comp' int2str(comp) '_run' int2str(run) '.mat'],'comp_total_length')
                            save([pwd '/LQepsMOEAPT/' problem '_x0_D_iter' int2str(i) '_comp' int2str(comp) '_run' int2str(run) '.mat'],'x0')
                        end
                        end
                        figure(102)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_DxComps_iter' int2str(i) '_run' int2str(run) '.png'])
                        figure(103)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_DyComps_iter' int2str(i) '_run' int2str(run) '.png'])
                
                        disp(['    ND Length = ' num2str(total_length_nondom)])
                        disp(['    D Length = ' num2str(total_length_dom)])
                
                        tau = total_length_nondom/mu;
                
                        save([pwd '/LQepsMOEAPT/' problem '_tau_' int2str(i) '_run' int2str(run) '.mat'],'tau')
                        save([pwd '/LQepsMOEAPT/' problem '_Archiver_' int2str(i) '_run' int2str(run) '.mat'],'Ax','Ay')
                        save([pwd '/LQepsMOEAPT/' problem '_num_ND_comp_' int2str(i) '_run' int2str(run) '.mat'],'num_ndcomp')
                        save([pwd '/LQepsMOEAPT/' problem '_num_D_comp_' int2str(i) '_run' int2str(run) '.mat'],'num_dcomp')
                    else %A lot of components, trim to 10 components (5 each)
                        k = 5;
                        %-----------NON DOMINATED x0 Selection------------------------%
                        plot_comp = num_ndcomp;
                        if plot_comp == -1
                            plot_comp = 1;
                        end
                        disp(['    Num ND Comp = ' int2str(num_ndcomp)])
                        figure(100)
                        markerTypes = repmat('o', 1, plot_comp+1);
                        if ~isempty(find(idx_nd == -1,1))
                            markerTypes(1) = 'x';
                        end
                        gscatter(Nx(:,1),Nx(:,2),idx_nd,[],markerTypes,'filled');
                        hold on
                        legend('Location','northeastoutside')
                        title('Non-Dominated Components (Dec. Space)')
                        figure(101)
                        gscatter(Ny(:,1),Ny(:,2),idx_nd,[],markerTypes,'filled');
                        hold on
                        scatter(Ry(:,1),Ry(:,2),'.')
                        legend('Location','northeastoutside')
                        title('Non-Dominated Components (Obj. Space)')
                        total_length_nondom = 0;
                        for comp = 1:num_ndcomp
                            X = Nx(idx_nd==comp,:);
                            Y = Ny(idx_nd==comp,:);
                            n = size(Y,1);
                            Points = sortrows(Y,1);
                            endpoints = [Points(1,:); Points(end,:)];
                            distances = zeros(1,n-1);
                            points_p_segment = zeros(1,n-1);
                            for j=1:n-1
                                distances(j) = norm(Points(j+1,:)-Points(j,:));
                            end
                            total_length_nondom = total_length_nondom + sum(distances); %SUM OF THE LENGTH SEGMENTS
                            comp_total_length = sum(distances);
                            save([pwd '/LQepsMOEAPT/' problem '_length_ND_iter' int2str(i) '_comp' int2str(comp) '_run' int2str(run) '.mat'],'comp_total_length')
                        end
                        X = Nx(idx_nd~=-1,:); %remove outliers for kmeans
                        Y = Ny(idx_nd~=-1,:);
                        if size(X,1)<k
                            X = Nx;
                            Y = Ny;
                        end
                        [~,~,~,~,midx] = kmedoids(X,k);
                        for startpoint=1:k
                            x0 = X(midx(startpoint),:);
                            y0 = Y(midx(startpoint),:);
                            figure(100)
                            scatter(x0(:,1),x0(:,2),'md','filled')
                            figure(101)
                            scatter(y0(:,1),y0(:,2),'cd','filled')
                            save([pwd '/LQepsMOEAPT/' problem '_x0_ND_iter' int2str(i) '_comp' int2str(startpoint) '_run' int2str(run) '.mat'],'x0')
                        end
                        figure(100)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_NDxComps_iter' int2str(i) '_run' int2str(run) '.png'])
                        figure(101)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_NDyComps_iter' int2str(i) '_run' int2str(run) '.png'])
                        %-----------DOMINATED x0 Selection------------------------%
                        if ~isempty(Dx)
                    %     r = r_dbscan*mean(pdist(Dx)); %radius is 10% of the average of all the distances
                    %     idx = dbscan(Dx,r_uplow,minpts);
    %                     idx_d = dbscan(Dx,r_uplow,minpts,'Distance','chebychev');
    %                     num_dcomp = max(idx_d);
                        plot_comp = num_dcomp;
                        if plot_comp == -1
                            plot_comp = 1;
                        end
                        disp(['    Num D Comp = ' int2str(num_dcomp)])
                        figure(102)
                        markerTypes = repmat('o', 1, plot_comp+1);
                        if ~isempty(find(idx_d == -1,1))
                            markerTypes(1) = 'x';
                        end
                        gscatter(Dx(:,1),Dx(:,2),idx_d,[],markerTypes,'filled');
                        hold on
                        legend('Location','northeastoutside')
                        title('Dominated Components (Dec. Space)')
                        figure(103)
                        gscatter(Dy(:,1),Dy(:,2),idx_d,[],markerTypes,'filled');
                        hold on
                        legend('Location','northeastoutside')
                        title('Dominated Components (Obj. Space)')
                        total_length_dom = 0;
                        for comp = 1:num_dcomp
                            X = Dx(idx_d==comp,:);
                            Y = Dy(idx_d==comp,:);
                            n = size(Y,1);
                            Points = sortrows(Y,1);
                            endpoints = [Points(1,:); Points(end,:)];
                            distances = zeros(1,n-1);
                            points_p_segment = zeros(1,n-1);
                            for j=1:n-1
                                distances(j) = norm(Points(j+1,:)-Points(j,:));
                            end
                            total_length_dom = total_length_dom + sum(distances); %SUM OF THE LENGTH SEGMENTS
                            comp_total_length = sum(distances);
                            save([pwd '/LQepsMOEAPT/' problem '_length_D_iter' int2str(i) '_comp' int2str(comp) '_run' int2str(run) '.mat'],'comp_total_length')
                        end
                        if size(Dx,1)<k
                            k = size(Dx,1);
                            midx = 1:k;
                        else
                            X = Dx(idx_d~=-1,:); %remove outliers for kmeans
                            Y = Dy(idx_d~=-1,:);
                            if size(X,1)<k %if cleaning is too harsh
                                X = Dx;
                                Y = Dy;
                            end
                            [~,~,~,~,midx] = kmedoids(X,k);
                        end
                        for startpoint=1:k
                            x0 = X(midx(startpoint),:);
                            y0 = Y(midx(startpoint),:);
                            figure(102)
                            scatter(x0(:,1),x0(:,2),'md','filled')
                            figure(103)
                            scatter(y0(:,1),y0(:,2),'cd','filled')
                            save([pwd '/LQepsMOEAPT/' problem '_x0_D_iter' int2str(i) '_comp' int2str(startpoint) '_run' int2str(run) '.mat'],'x0')
                        end
                        end
                        figure(102)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_DxComps_iter' int2str(i) '_run' int2str(run) '.png'])
                        figure(103)
                        saveas(gcf,[pwd '/LQepsMOEAPT/' problem '_DyComps_iter' int2str(i) '_run' int2str(run) '.png'])
                
                        disp(['    ND Length = ' num2str(total_length_nondom)])
                        disp(['    D Length = ' num2str(total_length_dom)])
                
                        tau = total_length_nondom/mu;
                        
                        num_ndcomp = k;
                        num_dcomp = k;
                        save([pwd '/LQepsMOEAPT/' problem '_tau_' int2str(i) '_run' int2str(run) '.mat'],'tau')
                        save([pwd '/LQepsMOEAPT/' problem '_Archiver_' int2str(i) '_run' int2str(run) '.mat'],'Ax','Ay')
                        save([pwd '/LQepsMOEAPT/' problem '_num_ND_comp_' int2str(i) '_run' int2str(run) '.mat'],'num_ndcomp')
                        save([pwd '/LQepsMOEAPT/' problem '_num_D_comp_' int2str(i) '_run' int2str(run) '.mat'],'num_dcomp')
                    end

                    %CORREGIR PARA 3D LUEGO!
                    if num_obj>2
                        if size(Ax,1)>= popsize
                            [~,~,~,~,midx] = kmedoids(Ax,target_size);
                        end
                        tau_comp = [];
                        for comp = 1:num_comp
                            X = Nx(idx_nd==comp,:);
                            Y = Ny(idx_nd==comp,:);
                            tau_comp(end+1) = estimate_tau(Y,k_nn);
                        end
                        tau = mean(tau_comp);
                        save([pwd '/LQepsMOEAPT/' problem '_tau_' int2str(i) '_run' int2str(run) '.mat'],'tau')
                    end

% % %                     %Simulate num points
% % %                     [~,I] = sort(Ry(:,1));
% % %                     Ay1 = Ry;
% % %                     Ay1(:,1) = Ry(I,1);
% % %                     Ay1(:,2) = Ry(I,2);
% % %                     deltay = 0.9*tau;
% % %                     num_inter = length(Ay1);
% % %                     z = Ay1(1,:);
% % %                     for j=1:num_inter
% % %                 %         if norm(z(end,:)-Ay1(j,:),"inf")>deltay 
% % %                         if norm(z(end,:)-Ay1(j,:))>deltay 
% % %                             z(end+1,:) = Ay1(j,:);
% % %                         end
% % %                     end
% % %                     disp([int2str(size(z,1)) ' / ' int2str(mu) ' points' ])
% % %                 %     figure
% % %                 % %     scatter(Ry(:,1),Ry(:,2),'.')
% % %                 % %     hold on
% % %                 %     scatter(z(:,1),z(:,2),'filled')
% % %                 %     title([int2str(size(z,1)) ' / ' int2str(mu) ' points' ])
            
                    %--------------------------I_ACC indicator--------------------------------%
                %     I_acc1_MOEA = I_acc(MOEAx,MOEAy,plat_name);
                    I_acc1_A = I_acc(Ax,Ay,plat_problem);
                    %-------------------------------------------------------------------------%
                    %----------------------------EDR indicator--------------------------------%
                %     I_EDR_MOEA = EDR(Ry, MOEAx, MOEAy, dx, dy, lb);
                    I_EDR_A = EDR(Ry, Ax, Ay, dx, dy, lower);
                    %-------------------------------------------------------------------------%
                    %----------------------------Archive Size --------------------------------%
                    Asize = size(Ax,1);
                    %-------------------------------------------------------------------------%
                
                
                    % disp(['I_{acc}^2(A) = ' num2str(I_acc2_A)])
                    disp(['    I_{acc}^1(A) = ' num2str(I_acc1_A)])
                %     disp(['I_{acc}^1(MOEA) = ' num2str(I_acc1_MOEA)])
                    disp(['    I_EDR(A) = ' num2str(I_EDR_A)])
                %     disp(['I_EDR(MOEA) = ' num2str(I_EDR_MOEA)])
                    disp(['    |A| = ' num2str(Asize)])
                    disp(['    feval(A) = ' num2str(i*popsize)])
                %     disp(['feval(MOEA) = ' num2str(maxFE)])
                    disp(['    \tau = ' num2str(tau)])
                    disp('    ----------------------    ')
                
                %     MOEA_feval = maxFE;
                    A_feval = i*popsize;
                
                %     save([pwd '/LQepsMOEAPT/' problem_name '/' problem_name '_INDICATORS.mat'],'I_acc1_PT','I_acc1_A','I_acc1_MOEA','I_EDR_A','I_EDR_PT','I_EDR_MOEA','PTsize','MOEA_feval','PT_feval','A_feval','Asize')
                    save([pwd '/LQepsMOEAPT/' problem '_INDICATORS_' int2str(i) '_run' int2str(run) '.mat'],'I_acc1_A','I_EDR_A','A_feval','Asize')
                end
            end
        
        
            % result{:,1} are the number of function evaluations
            % result{:,2} are the MOEA results
            % result{:,3} are the Archvier results
            % % % % % %TEST DATA:
            % % % % % Px = [];
            % % % % % Py = [];
            % % % % % for i=1:100
            % % % % %     Px = [Px; result{i,3}.decs];
            % % % % %     Py = [Py; result{i,3}.objs];
            % % % % % end
            % % % % % unique_Py = unique(Py, 'rows');
            % % % % % unique_Px = unique(Px, 'rows');
            % % % % Run only acrhiver
            % % % for i=1:100
            % % %     disp(i)
            % % %     Px = result{i,3}.decs;
            % % %     Py = result{i,3}.objs;
            % % %     if ishi
            % % %         [Px,Py] = ishibuchi(Px,Py,alpha);
            % % %     end
            % % %     [Ax,Ay] = ArchiveUpdatePQeps_c(Ax,Ay,Px,Py,eps,delta_neigh);
            % % % end
            
        end
    end
end