function [dom] = dominance(a,b)

    dom = prod(double(a<=b));

end